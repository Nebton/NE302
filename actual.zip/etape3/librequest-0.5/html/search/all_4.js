var searchData=
[
  ['getrequest',['getRequest',['../request_8h.html#a84f3d458b916b971024022f2359ac338',1,'request.h']]]
];
