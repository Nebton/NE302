var searchData=
[
  ['writedirectclient',['writeDirectClient',['../socket_8c.html#ad85da2e74873990c15111d9c7b4dc6b3',1,'socket.c']]]
];
