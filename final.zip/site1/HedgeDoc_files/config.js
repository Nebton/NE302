window.domain = '192.168.132.15'
window.urlpath = ''
window.debug = false
window.version = '1.8.2'

window.allowedUploadMimeTypes = ["image/jpeg","image/png","image/gif","image/svg+xml"]

window.linkifyHeaderStyle = 'gfm'

window.DROPBOX_APP_KEY = ''

window.cookiePolicy = 'lax'
