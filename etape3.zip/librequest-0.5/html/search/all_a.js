var searchData=
[
  ['readable',['READABLE',['../socket_8c.html#a663646f2d16be375255c4938b12d2033a8daf2d039f917fa102a834bb2b0b1525',1,'socket.c']]],
  ['readlen',['READLEN',['../socket_8c.html#ac22c8883e9c8e4734afcac92df2f983c',1,'socket.c']]],
  ['requestshutdownsocket',['requestShutdownSocket',['../socket_8c.html#af8b1b52a1fe661d7ab6e33f6687e6d4f',1,'socket.c']]]
];
