var searchData=
[
  ['search',['search',['../structs__field.html#aad4b53dc2fef51a522ec724c45532afb',1,'s_field']]],
  ['state',['state',['../structs__client.html#a97bb33d47070233757d0ade6f83b8c82',1,'s_client']]]
];
