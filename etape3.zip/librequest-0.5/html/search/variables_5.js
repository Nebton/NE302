var searchData=
[
  ['nb',['nb',['../structs__field.html#a2509e57ad638582c3a979e1ae036a5aa',1,'s_field']]]
];
