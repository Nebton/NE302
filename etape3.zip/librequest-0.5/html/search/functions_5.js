var searchData=
[
  ['writedirectclient',['writeDirectClient',['../request_8h.html#ad85da2e74873990c15111d9c7b4dc6b3',1,'request.h']]]
];
