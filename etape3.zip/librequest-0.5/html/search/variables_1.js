var searchData=
[
  ['clientaddress',['clientAddress',['../structmessage.html#a3c3a02f02d5ba650223498f95f30cb4c',1,'message']]],
  ['clientid',['clientId',['../structmessage.html#a14bfec4a2137426f4b33df4c470310da',1,'message']]]
];
