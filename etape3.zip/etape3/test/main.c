#include <stdio.h>
#include <string.h>
int endswith(char *str, char *suffix) {
	char *ext = strrchr(str,'.');
	if(!ext) {
		return 0;
	}
	else {
		return(!strcmp(ext,suffix));
	}

}

int main(){
	FILE *fp=fopen("test.png", "rb");
	if(fp==NULL) {
		fprintf(stderr, "cannot open input file\n");
		return 1;
	}
	int i;
	char c;
	char *str;
	for(i=0; (c=getc(fp)) != EOF; i++) {
		printf("%d", c);
	}
	return 0;
}
