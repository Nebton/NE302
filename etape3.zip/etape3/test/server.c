#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

// for librequest
#include "request.h"

// for parser

// this will declare internal type used by the parser
#include "httpparser.h"
#include "api.h"

#define ERROR "HTTP/1.0 400 SUCKA\r\n\r\n"
#define REPONSE "HTTP/1.0 200 OK\r\nContent-type: text/html\r\n"
#define True 1
#define False 0
//Rule 1 : Si la version HTTP est 1.1, il doit y avoir un HOST
int Rule1() {
	_Token *version,*host,*root;
	root=getRootTree();
	if(version=searchTree(root,"HTTP_version")) {
		int m;
		char *b;
		b = getElementValue(((Lnode *)version->node),&m);
		if(!strncmp(b,"HTTP/1.1",8)) {
			//on verifie si la version HTTP est 1.1
			if(!(host=searchTree( root,"Host_header"))) {
				//Version 1.1 and no HOST : 400 BAD REQUEST
				#undef ERROR
				#define ERROR "HTTP/1.1 400 BAD REQUEST\r\n"
				return False;
			}

		}
		else {
			return True;
		}
	}
	else {
		return False;
	}
	return True;
}

//Rule 2 : Si la version HTTP est 1.0, il peut pas y avoir un Transfer-Encoding
int Rule2() {
	_Token *version,*transfer,*root;
	root=getRootTree();
	if(version=searchTree(root,"HTTP_version")) {
		int m;
		char *b;
		b = getElementValue(((Lnode *)version->node),&m);
		if(strncmp(b,"HTTP/1.0",8)==0) {
			//on verifie si la version HTTP est 1.0
			if((transfer=searchTree( root,"Transfer_Encoding_header"))) {
				//Version 1.0 and Transfer Encoding HEADER : 400 BAD REQUEST
				#undef ERROR
				#define ERROR "HTTP/1.0 400 BAD REQUEST\r\n"
				return False;
			}
			else {
				return True;
			}

		}
		else {
			return True;
		}
	}
	else {
		return False;
	}

}

//Rule 3 : S'il y a deja un Transfer-Encoding_Header, il peut pas y avoir un Content Length
int Rule3() {
	_Token *version,*transfer,*root,*content;
	root=getRootTree();
	if(transfer=searchTree(root,"Transfer_Encoding_header")) {
			if((content=searchTree( root,"Content_Length_header"))) {
				//Transfer Encoding and Content LENGTH : 400 BAD REQUEST
				#undef ERROR
				#define ERROR "HTTP/1.1 400 BAD REQUEST\r\n"
				return False;
			}
			else {
				return True;
			}

		}
		else {
			return True;
		}
	}



// Following function extracts characters present in `src`
// between `m` and `n` (excluding `n`)
char* substr(const char *src, int m, int n)
{
    // get the length of the destination string
    int len = n - m;

    // allocate (len + 1) chars for destination (+1 for extra null character)
    char *dest = (char*)malloc(sizeof(char) * (len + 1));

    // extracts characters between m'th and n'th index from source string
    // and copy them into the destination string
    for (int i = m; i < n && (*(src + i) != '\0'); i++)
    {
        *dest = *(src + i);
        dest++;
    }

    // null-terminate the destination string
    *dest = '\0';

    // return the destination string
    return dest - len;
}


int main(int argc, char *argv[])
{
	message *requete;
	int res;
	while ( 1 ) {
		// on attend la reception d'une requete HTTP requete pointera vers une ressource allouée par librequest.
		if ((requete=getRequest(8080)) == NULL ) return -1;

		// Affichage de debug
		printf("#########################################\nDemande recue depuis le client %d\n",requete->clientId);
		printf("Client [%d] [%s:%d]\n",requete->clientId,inet_ntoa(requete->clientAddress->sin_addr),htons(requete->clientAddress->sin_port));
		printf("Contenu de la demande \r\n[%.*s]\n",requete->len,requete->buf);
		if (res=parseur(requete->buf,requete->len) && Rule1() && Rule2()) {
			//Requete syntaxiquement et semantiquement correcte
			_Token *r,*tok,*root,*req,*meth;
			writeDirectClient(requete->clientId,REPONSE,strlen(REPONSE));
			// get the root of the tree this is no longer opaque since we know the internal type with httpparser.h
			//void *root;

			root=getRootTree();
			req=searchTree(root,"request_target");
			meth=searchTree(root,"method");
			Lnode *method;
			method =(Lnode *)meth->node;
			//printf("method is [%.*s] at level %d\n\n\n", method->len, method->value, method->level );
			if(strncmp(method->value,"GET",method->len)==0) {
				// node is no longer opaque
				Lnode *request;
				request=(Lnode *)req->node;
				char *file;
				//printf("request target is [%.*s] at level %d\n\n\n", request->len, request->value, request->level );

				if(strncmp(request->value,"/",request->len) == 0) {
					file="index.html";

				}
				else {
					file=substr(request->value,1,request->len);

				}
				//printf("file is %s\n", file);

				//on stocke les contenus du fichier file dans string
				FILE *f = fopen(file, "rb");
				fseek(f, 0, SEEK_END);
				long fsize = ftell(f);
				fseek(f, 0, SEEK_SET);
				char *string = malloc(fsize + 1);
				fread(string, fsize, 1, f);
				fclose(f);
				string[fsize] = 0;

				//on stocke la taille de string dans stringlen
				int length = snprintf( NULL, 0, "%d", strlen(string) );
				char *stringlen = malloc(length + 1);
				snprintf( stringlen, length + 1, "%d", strlen(string) );


				//printf("%s\n", string);
				writeDirectClient(requete->clientId,"Content-Length: ", strlen("Content-Length: "));
				writeDirectClient(requete->clientId, stringlen, strlen(stringlen));
				writeDirectClient(requete->clientId,"\r\n\r\n", 4);

				writeDirectClient(requete->clientId,string,strlen(string));
			}
			else if(strncmp(method->value,"HEAD",method->len)==0) {
				// node is no longer opaque
				Lnode *request;
				request=(Lnode *)req->node;
				char *file;
				//printf("request target is [%.*s] at level %d\n\n\n", request->len, request->value, request->level );

				if(strncmp(request->value,"/",request->len) == 0) {
					file="index.html";

				}
				else {
					file=substr(request->value,1,request->len);

				}
				//printf("file is %s\n", file);

				//on stocke les contenus du fichier file dans string
				FILE *f = fopen(file, "rb");
				fseek(f, 0, SEEK_END);
				long fsize = ftell(f);
				fseek(f, 0, SEEK_SET);
				char *string = malloc(fsize + 1);
				fread(string, fsize, 1, f);
				fclose(f);
				string[fsize] = 0;

				//on stocke la taille de string dans stringlen
				int length = snprintf( NULL, 0, "%d", strlen(string) );
				char *stringlen = malloc(length + 1);
				snprintf( stringlen, length + 1, "%d", strlen(string) );


				//printf("%s\n", string);
				writeDirectClient(requete->clientId,"Content-Length: ", strlen("Content-Length: "));
				writeDirectClient(requete->clientId, stringlen, strlen(stringlen));
				writeDirectClient(requete->clientId,"\r\n\r\n", 4);

			}


		purgeElement(&req);
		purgeTree(root);
		}
		else {
			writeDirectClient(requete->clientId,ERROR,strlen(ERROR));
		}
		endWriteDirectClient(requete->clientId);
		requestShutdownSocket(requete->clientId);
	// on ne se sert plus de requete a partir de maintenant, on peut donc liberer...
	freeRequest(requete);
	}
	return (1);
}


//A faire :
/*
	-Differencier entre les differentes types de requetes (.png, .html) (et utiliser une methode differente de stocker string (contenu du fichier voulu)
	pour les images car elles sont binaires (un 0 entraine un fin de caractere))
	-Finir de definir les regles semantiques
	-Implementer GET, HEAD et POST (si possible)

*/
