var searchData=
[
  ['state',['state',['../socket_8c.html#a47b936e7004e9cfa6c34be66fb9b4fde',1,'socket.c']]]
];
