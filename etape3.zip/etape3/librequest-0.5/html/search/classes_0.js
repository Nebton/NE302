var searchData=
[
  ['message',['message',['../structmessage.html',1,'']]]
];
