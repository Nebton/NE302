var searchData=
[
  ['timeout',['timeout',['../structs__client.html#afa7be8b85625b1bf5cda13fad9fd5814',1,'s_client::timeout()'],['../socket_8c.html#a45ba202b05caf39795aeca91b0ae547e',1,'TIMEOUT():&#160;socket.c']]]
];
