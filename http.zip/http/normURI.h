#ifndef __NORM_URI__H
#define __NORM_URI__H

char* minuscule(char* car);

char* norm1(char* s);

char* norm2(char* s);

char* normalisation(char* url);


#endif
