<?php 
phpinfo();
phpinfo();
phpinfo();
?>
